const students = [
    { id: 1, name: 'Arun Kumar', age: 18, grade: 'A' },
    { id: 2, name: 'Priya Sharma', age: 19, grade: 'B' },
    { id: 3, name: 'Rahul Singh', age: 17, grade: 'A' },
    { id: 4, name: 'Sneha Reddy', age: 18, grade: 'C' }
];

function renderStudentTable() {
    const tbody = document.getElementById('student-table-body');
    tbody.innerHTML = '';
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.age}</td>
            <td>${student.grade}</td>
        `;
        tbody.appendChild(row);
    });
}

document.addEventListener('DOMContentLoaded', renderStudentTable);